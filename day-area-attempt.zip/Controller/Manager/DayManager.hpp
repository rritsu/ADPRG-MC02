#pragma once

namespace managers {
    class DayManager {
        private:
            


        private:
            static DayManager* P_SHARED_INSTANCE;

        private:
            DayManager();
            DayManager(const DayManager&);
            DayManager& operator = (const DayManager&);

        public:
            static DayManager* getInstance();

    };
}
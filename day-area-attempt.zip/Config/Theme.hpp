#pragma once

#include <SFML/Graphics.hpp>

const sf::Color COLOR_BLACK = sf::Color(0, 0, 0);
const sf::Color COLOR_WHITE = sf::Color(255, 255, 255);
const sf::Color COLOR_RED = sf::Color(255, 0, 0);
const sf::Color COLOR_GREEN = sf::Color(0, 255, 0);
#pragma once

const int SCREEN_WIDTH  = 1200;
const int SCREEN_HEIGHT = 700;
const int GRID_WIDTH = 12;
const int GRID_HEIGHT = 7;
const float FRAME_RATE_LIMIT = 60.0f;

#pragma once

#include "../Utility/Utility.hpp"
#include "SceneManager.hpp"
#include "../../Model/Scene/AreaScene.hpp"

namespace managers {
    using namespace utilities;
    using namespace scenes;

    class AreaManager {
        private:
            int nNumRooms;
            int nPrevRoom;
            int nCurrentRoom;
            std::vector<int> vecIndex;
            std::vector<int> vecArea;

        public:
           // void initializeConnectedRooms();
            void generateArea();
            void generateRooms();

        private:
            void setConnectedIndeces();
            void clearIndeces();
            int getRandomNumber(int nLowerbound, int nUpperbound);
            bool checkDuplicate(int nIndex);

        private:
            static AreaManager* P_SHARED_INSTANCE;

        private:
            AreaManager();
            AreaManager(const AreaManager&);
            AreaManager& operator = (const AreaManager&);

        public:
            static AreaManager* getInstance();
    };

}

#include "AreaManager.hpp"

using namespace managers;

void AreaManager::generateArea() { 
    //generate how many scraps
    //generate how many rooms
    //connection of rooms
    //doors smth smth
    //enemies
    this->nNumRooms = Utility::getInstance()->getRandomNumber(4, 9);
    while(this->nCurrentRoom == 5) {
        this->nCurrentRoom = Utility::getInstance()->getRandomNumber(1, 9);
    }

    for(int i = 1; i <= nNumRooms; i++) {
        this->setConnectedIndeces();
        SceneManager::getInstance()->registerScene(new AreaScene(this->vecIndex , this->nCurrentRoom, this->nPrevRoom));
        this->vecArea.push_back(this->nCurrentRoom);
        this->nPrevRoom = this->nCurrentRoom;
        int nTempIndex = Utility::getInstance()->getRandomNumber(0, this->vecIndex.size() - 1);
        this->vecArea.push_back(this->vecIndex[nTempIndex]);
        this->nCurrentRoom = this->vecIndex[nTempIndex];
        this->clearIndeces();
    }

//might need to make a Area.cpp and .hpp but im not sure yet
//

}

void AreaManager::setConnectedIndeces() {
    switch(this->nCurrentRoom) {
        case 1:
            this->vecIndex.push_back(2);
            this->vecIndex.push_back(4);
            break;
            
        case 2:
            this->vecIndex.push_back(1);
            this->vecIndex.push_back(3);
            break;

        case 3:
            this->vecIndex.push_back(2);
            this->vecIndex.push_back(6);
            break;

        case 4:
            this->vecIndex.push_back(1);
            this->vecIndex.push_back(7);
            break;
        
        case 5:
            this->vecIndex.push_back(2);
            this->vecIndex.push_back(4);
            this->vecIndex.push_back(6);
            this->vecIndex.push_back(8);
            break;

        case 6:
            this->vecIndex.push_back(3);
            this->vecIndex.push_back(9);
            break;

        case 7:
            this->vecIndex.push_back(4);
            this->vecIndex.push_back(8);
            break;

        case 8:
            this->vecIndex.push_back(7);
            this->vecIndex.push_back(9);
            break;

        case 9:
            this->vecIndex.push_back(6);
            this->vecIndex.push_back(8);
            break;

        default:
            break;
    }
}

void AreaManager::clearIndeces() {
    this->vecIndex.clear();
}

AreaManager* AreaManager::P_SHARED_INSTANCE = NULL;
AreaManager::AreaManager() {
    this->nNumRooms = 0;
    this->nPrevRoom = 0;
    this->nCurrentRoom = 5;
    this->vecArea = {};
    this->vecIndex = {};
}
AreaManager::AreaManager(const AreaManager&) {}

AreaManager* AreaManager::getInstance() {
    if(P_SHARED_INSTANCE == NULL)
        P_SHARED_INSTANCE = new AreaManager();

    return P_SHARED_INSTANCE;
}
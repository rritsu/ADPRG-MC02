#include "DayManager.hpp"
using namespace managers;

DayManager* DayManager::P_SHARED_INSTANCE = NULL;
DayManager::DayManager() {}
DayManager::DayManager(const DayManager&) {}

DayManager* DayManager::getInstance() {
    if(P_SHARED_INSTANCE == NULL) {
        P_SHARED_INSTANCE = new DayManager();
    }
    return P_SHARED_INSTANCE;
}

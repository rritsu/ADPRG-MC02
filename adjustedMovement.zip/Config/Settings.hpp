#pragma once

const int SCREEN_WIDTH  = 1280;
const int SCREEN_HEIGHT = 720;
const float FRAME_RATE_LIMIT = 60.0f;

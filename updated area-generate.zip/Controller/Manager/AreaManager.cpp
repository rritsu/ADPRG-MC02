#include "AreaManager.hpp"

using namespace managers;

void AreaManager::generateArea() { 
    //generate how many scraps
    //generate how many rooms
    //connection of rooms
    //doors smth smth
    //enemies
    
    this->generateRooms();
    SceneManager::getInstance()->loadScene(this->getRoomTag(this->nEntryRoom));
}

void AreaManager::generateRooms() {
    int nTempIndex = 0;

    this->nNumRooms = this->getRandomNumber(4, 9-3);
    std::cout << nNumRooms << std::endl;
    
    while(this->nEntryRoom == 5) {
        this->nEntryRoom = this->getRandomNumber(1, 9);
    }
    this->nCurrentRoom = this->nEntryRoom;

    for(int i = 1; i <= nNumRooms; i++) {
        this->setConnectedIndeces();
        SceneTag tempTag = this->getRoomTag(i);
        SceneManager::getInstance()->registerScene(new AreaScene(tempTag, this->nCurrentRoom, this->nPrevRoom));
        this->vecRooms.push_back(this->nCurrentRoom);
        this->nPrevRoom = this->nCurrentRoom;

        do{
            nTempIndex = this->getRandomNumber(0, this->vecIndeces.size());
        }while(this->checkDuplicate(nTempIndex));

        this->nCurrentRoom = this->vecIndeces[nTempIndex];
        this->clearIndeces();

       // std::cout << "loop" << std::endl;
    }

    //checking
    for(int num : this->vecRooms) {
        std::cout << "room " << num << std::endl;
    }
}

bool AreaManager::checkDuplicate (int nIndex) {
    for(int A : this->vecRooms) {
        if(A == this->vecIndeces[nIndex])
            return true;
    }
    return false;
}

void AreaManager::setConnectedIndeces() {
    switch(this->nCurrentRoom) {
        case 1:
            this->vecIndeces.push_back(2);
            this->vecIndeces.push_back(4);
            break;
            
        case 2:
            this->vecIndeces.push_back(1);
            this->vecIndeces.push_back(3);
            this->vecIndeces.push_back(5);
            break;

        case 3:
            this->vecIndeces.push_back(2);
            this->vecIndeces.push_back(6);
            break;

        case 4:
            this->vecIndeces.push_back(1);
            this->vecIndeces.push_back(5);
            this->vecIndeces.push_back(7);
            break;
        
        case 5:
            this->vecIndeces.push_back(2);
            this->vecIndeces.push_back(4);
            this->vecIndeces.push_back(6);
            this->vecIndeces.push_back(8);
            break;

        case 6:
            this->vecIndeces.push_back(3);
            this->vecIndeces.push_back(5);
            this->vecIndeces.push_back(9);
            break;

        case 7:
            this->vecIndeces.push_back(4);
            this->vecIndeces.push_back(8);
            break;

        case 8:
            this->vecIndeces.push_back(5);
            this->vecIndeces.push_back(7);
            this->vecIndeces.push_back(9);
            break;

        case 9:
            this->vecIndeces.push_back(6);
            this->vecIndeces.push_back(8);
            break;

        default:
            break;
    }
}

void AreaManager::clearIndeces() {
    this->vecIndeces.clear();
}

int AreaManager::getRandomNumber(int nLowerbound, int nUpperbound) {

    return nLowerbound + rand() % nUpperbound;;
}

std::vector<int> AreaManager::getVecRooms() {
    return this->vecRooms;
}

SceneTag AreaManager::getRoomTag(int nIndex) {
    SceneTag nRet;
    switch(nIndex) {
        case 1: nRet = SceneTag::ROOM1_SCENE; break;
        case 2: nRet = SceneTag::ROOM2_SCENE; break;
        case 3: nRet = SceneTag::ROOM3_SCENE; break;
        case 4: nRet = SceneTag::ROOM4_SCENE; break;
        case 5: nRet = SceneTag::ROOM5_SCENE; break;
        case 6: nRet = SceneTag::ROOM6_SCENE; break;
        case 7: nRet = SceneTag::ROOM7_SCENE; break;
        case 8: nRet = SceneTag::ROOM8_SCENE; break;
        case 9: nRet = SceneTag::ROOM9_SCENE; break;
        default: break;
    }
    return nRet;
}

AreaManager* AreaManager::P_SHARED_INSTANCE = NULL;
AreaManager::AreaManager() {
    this->nNumRooms = 0;
    this->nEntryRoom = 5;
    this->nPrevRoom = 0;
    this->nCurrentRoom = 0;
    this->vecRooms = {};
    this->vecIndeces = {};
}
AreaManager::AreaManager(const AreaManager&) {}

AreaManager* AreaManager::getInstance() {
    if(P_SHARED_INSTANCE == NULL)
        P_SHARED_INSTANCE = new AreaManager();

    return P_SHARED_INSTANCE;
}